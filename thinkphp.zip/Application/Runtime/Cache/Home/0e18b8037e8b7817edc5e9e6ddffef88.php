<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="keywords" content="南瓜鱼 hyhning thinkphp框架作品" />
<meta name="description" content="南瓜鱼是个人创作网页" />
<title>...</title>
<link rel="stylesheet" type="text/css" href="/thinkphp/Public/CSS/bootstrap.min.css">
<link rel="stylesheet" href="/thinkphp/Public/Css/text.css" />
<!--[if lt IE 9]>
  <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

</head>
<body>
	<div class="container-fluid">
		<div id="outer">
			<div class="box">
				<div class="pic1">
					<img src="/thinkphp/Public/Images/2211.jpg">				
				</div>
			</div>
			<div class="box">
				<div class="pic2">
					<img src="/thinkphp/Public/Images/2212.jpg">				
				</div>
			</div>
			<div class="box">
				<div class="pic3">
					<img src="/thinkphp/Public/Images/2213.jpg">				
				</div>
			</div>
			<div class="box">
				<div class="pic4">
					<img src="/thinkphp/Public/Images/2214.jpg">				
				</div>
			</div>
			<div id="ha">1</div>
			<div id="da">2</div>

		</div>	
	</div>



<script type="text/javascript" src="/thinkphp/Public/Js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/thinkphp/Public/Js/bootstrap.min.js"></script>
<script type="text/javascript" src="/thinkphp/Public/Js/Frame/jquery-mousewheel"></script>
<script type="text/javascript"> 

</script> 
</body>
</html>