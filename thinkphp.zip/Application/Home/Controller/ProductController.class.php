<?php
namespace Home\Controller;
use Think\Controller;
class ProductController extends Controller {
    // public function product(){

    // }
}